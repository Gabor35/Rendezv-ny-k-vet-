﻿using System;
using System.Collections.Generic;

namespace esemenyrendezo.Models;

public partial class Felhasznalo
{
    public int Id { get; set; }

    public string FelhasznaloNev { get; set; } = null!;

    public string TeljesNev { get; set; } = null!;

    public string Salt { get; set; } = null!;

    public string Hash { get; set; } = null!;

    public string Email { get; set; } = null!;

    public int Jogosultsag { get; set; }

    public int Aktiv { get; set; }

    public DateTime? RegisztracioDatuma { get; set; }

    public virtual ICollection<Bejelentkeze>? Bejelentkezes { get; set; } = new List<Bejelentkeze>();

    public virtual ICollection<Kijelentkeze>? Kijelentkezes { get; set; } = new List<Kijelentkeze>();

    public virtual ICollection<Reszvetel>? Reszvetels { get; set; } = new List<Reszvetel>();
}
