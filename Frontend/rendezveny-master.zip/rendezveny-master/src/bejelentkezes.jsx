import React, { useState } from 'react';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';

function App() {
  const [showLogin, setShowLogin] = useState(false);

  const toggleLoginPanel = () => {
    setShowLogin(!showLogin);
  };

  return (
    <div>
      {/* Header */}
      <header className="d-flex justify-content-between align-items-center p-3 bg-light">
        <div className="d-flex align-items-center">
          <img
            src="https://source.unsplash.com/random/50x50?logo"
            alt="Logo"
            className="me-2"
            style={{ width: '50px', height: '50px' }}
          />
          <h1 className="h4 mb-0">Rendezvény követő</h1>
        </div>
        <div>
          <button className="btn btn-outline-primary me-2" onClick={toggleLoginPanel}>
            Bejelentkezés
          </button>
          <button className="btn btn-primary">Regisztráció</button>
        </div>
      </header>

      {/* Login Panel */}
      {showLogin && (
        <div className="position-fixed top-0 start-0 w-100 h-100 bg-dark bg-opacity-50 d-flex justify-content-center align-items-center">
          <div className="card" style={{ width: '400px' }}>
            <div className="card-header d-flex justify-content-between align-items-center">
              <h5 className="mb-0">Bejelentkezés</h5>
              <button className="btn-close" onClick={toggleLoginPanel}></button>
            </div>
            <div className="card-body">
              <form>
                <div className="mb-3">
                  <label htmlFor="email" className="form-label">
                    Email cím
                  </label>
                  <input type="email" className="form-control" id="email" placeholder="Add meg az email címed" />
                </div>
                <div className="mb-3">
                  <label htmlFor="password" className="form-label">
                    Jelszó
                  </label>
                  <input type="password" className="form-control" id="password" placeholder="Add meg a jelszavad" />
                </div>
                <button type="submit" className="btn btn-primary w-100">
                  Bejelentkezés
                </button>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <div className="container mt-4">
        <h2 className="text-center mb-4">Események</h2>
        <div className="row">
          {[1, 2, 3, 4].map((event, index) => (
            <div className="col-md-3 mb-4" key={index}>
              <div className="card">
                <img
                  src={`https://source.unsplash.com/random/200x200?event-${event}`}
                  className="card-img-top"
                  alt={`Event ${event}`}
                />
                <div className="card-body">
                  <h5 className="card-title">Event {event}</h5>
                  <p className="card-text">Ez egy rendezvény rövid leírása.</p>
                  <button className="btn btn-primary">Részletek</button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default App;
